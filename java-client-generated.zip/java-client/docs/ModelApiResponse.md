
# ModelApiResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **Integer** |  |  [optional]
**type** | **String** |  |  [optional]
**message** | **String** |  |  [optional]



